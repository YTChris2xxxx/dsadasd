# ToX-Fortnite-Optimizer
An Optimization Tool Specifically Designed for Fortnite, Featuring Hundreds of Fortnite-Specific Tweaks!

# Preview

![image](https://cdn.discordapp.com/attachments/1189338852691812452/1344975101803630602/image.png?ex=67c2dd2c&is=67c18bac&hm=e2e02111ef2b68571478bc1bb8d87acd3ee339f8c44ad1e49e343ee2f7281a5e&)
